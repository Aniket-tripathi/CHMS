const con = require("../db");
const moment = require("moment");

// Function to handle schedule insertion
exports.insertSchedule = async (req, res) => {
  const { month, clinicid, apsolts } = req.body;

  // Validate input
  if (!month || !apsolts || !clinicid) {
    return res.status(400).send("Month, clinic ID, and number of appointments are required.");
  }

  // Validate the month format (YYYY-MM)
  if (!moment(month, "YYYY-MM", true).isValid()) {
    return res.status(400).send("Invalid month format. Please use 'YYYY-MM'.");
  }

  // Format the current date and time for South Africa timezone
  const now = new Date();
  const southAfricaTime = new Intl.DateTimeFormat("en-ZA", {
    timeZone: "Africa/Johannesburg",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(now);

  const formattedDate = `${southAfricaTime[4].value.padStart(2, "0")}-${southAfricaTime[2].value.padStart(2, "0")}-${southAfricaTime[0].value}`;
  const formattedTime = `${southAfricaTime[6].value}:${southAfricaTime[8].value}:${southAfricaTime[10].value}`;

  // Parse month and determine start and end dates
  const startDate = moment(`${month}-01`);
  const endDate = startDate.clone().endOf("month");

  try {
    const success = await insertScheduleForRange(clinicid, startDate, endDate, apsolts, formattedDate, formattedTime);
    if (success) {
      return res.status(200).json({
        success: true,
        message: "Monthly schedule inserted successfully.",
      });
    } else {
      return res.status(500).json({
        success: false,
        message: "Failed to insert monthly schedule.",
      });
    }
  } catch (error) {
    console.error("Error inserting schedule:", error);
    return res.status(500).json({
      success: false,
      message: "An error occurred while inserting the schedule.",
    });
  }
};

// Helper function to insert schedule for a range of dates
async function insertScheduleForRange(clinicid, startDate, endDate, noOfAppointments, formattedDate, formattedTime) {
  const currentDate = moment().format("DD-MM-YYYY");
  const scheduleQuery = `SELECT csid FROM clinic_schedule WHERE clinicid = $1 AND clinic_sch_dt = $2`;
  const scheduleResult = await con.query(scheduleQuery, [clinicid, currentDate]);

  let scheduleId;
  if (scheduleResult.rows.length > 0) {
    scheduleId = scheduleResult.rows[0].csid;
  } else {
    const insertScheduleQuery = `INSERT INTO clinic_schedule (clinicid, clinic_sch_dt, type,time,date) VALUES ($1, $2, $3,$4,$5) RETURNING csid`;
    const insertResult = await con.query(insertScheduleQuery, [clinicid, currentDate, "monthly",formattedDate,formattedTime]);
    scheduleId = insertResult.rows[0].csid;
  }

  const timeSlots = [
    { from: "07:30", to: "09:00" },
    { from: "09:00", to: "11:00" },
    { from: "11:00", to: "13:00" },
    { from: "13:00", to: "16:00" }, // Last time slot
  ];

  const diagnosticsQuery = `SELECT ap_reasonid FROM appointment_reason`;
  const diagnosticsResult = await con.query(diagnosticsQuery);
  const reasons = diagnosticsResult.rows.map((row) => row.ap_reasonid);

  let success = true;
  let currentDateClone = startDate.clone();

  while (currentDateClone.isSameOrBefore(endDate)) {
    const scheduleDate = currentDateClone.format("DD-MM-YYYY");

    for (const slot of timeSlots) {
      for (const reason of reasons) {
        const insertWorkingHoursQuery = `
          INSERT INTO clinic_working_hours (
            cwhdate, cwhfrom, cwhto, noofappointment, app_reasonid, clinic_sch_id, clinicid, action, date, time
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        `;
        try {
          const insertResult = await con.query(insertWorkingHoursQuery, [
            scheduleDate,
            slot.from,
            slot.to,
            noOfAppointments,
            reason,
            scheduleId,
            clinicid,
            "monthly",
            formattedDate,
            formattedTime,
          ]);
          if (insertResult.rowCount === 0) {
            console.error(`Failed to insert for slot: ${slot.from}-${slot.to} and reason: ${reason}`);
            success = false;
          }
        } catch (error) {
          console.error("Error while inserting:", error);
          success = false;
        }
      }
    }

    currentDateClone.add(1, "day");
  }

  return success;
}


exports.getSchedule = (req, res) => {
  try {
    // SQL query to join clinic_schedule with clinics table
    const query = `
      SELECT 
        cs.*, 
       c.*
      FROM public.clinic_schedule cs
      LEFT JOIN public.clinics c ON cs.clinicid = c.clinicid
    `;

    // Execute the query
    con.query(query, (err, result) => {
      if (err) {
        console.error('Database Error:', err);
        return res.status(500).json({ error: 'Database query failed', details: err });
      }

      // Return the result as JSON
      console.log('Query result:', result.rows);
      return res.status(200).json({ schedules: result.rows });
    });
  } catch (err) {
    console.error('Unexpected error:', err);
    return res.status(500).json({ error: 'Internal Server Error', details: err });
  }
};



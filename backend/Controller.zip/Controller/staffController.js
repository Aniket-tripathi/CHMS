const con = require('../db');
const bcrypt = require('bcrypt');
const { sendEmail } = require("../Utils/email.js");
// const redisClient = require('../redis.js')

exports.insertStaff = async (req, res) => {
  const {
    fname,
    lname,
    gender,
    username,
    email,
    password,
    clinicId,
    roleid,
    desgid,
    deptId,
    dob,
    doj,
    maritalstatus,
    province,
    district,
    subdistrict,
    qualification,
    sancno,
    hpcsano,
    contactno,
    profileimg,
    address,
    level,
    added_by,
    employmentStatus,
    staffType
  } = req.body;

  const now = new Date();
  const southAfricaTime = new Intl.DateTimeFormat('en-ZA', {
    timeZone: 'Africa/Johannesburg',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).formatToParts(now);

  const adddate = `${southAfricaTime[4].value.padStart(2, '0')}-${southAfricaTime[2].value.padStart(2, '0')}-${southAfricaTime[0].value}`;
  const addtime = `${southAfricaTime[6].value}:${southAfricaTime[8].value}:${southAfricaTime[10].value}`;
  const status = 'inactive';

  // Check if staffEmail already exists
  const emailCheckQuery = `SELECT * FROM staff WHERE "email" = $1`;

  try {
    const emailCheckResult = await con.query(emailCheckQuery, [email]);
    if (emailCheckResult.rows.length > 0) {
      return res.status(409).send({
        error: 'Conflict',
        message: 'A Staff with this email already exists.'
      });
    }

    // Hash the password before inserting
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // If email is unique, insert the new clinic
    const insertQuery = `
      INSERT INTO staff(
        "fname", "lname", "gender", "username", 
        "email", "password", "clinicId", roleid, 
        desgid, "deptId", "dob", "doj", "maritalstatus", "province",
        "district", "subdistrict", "qualification", "sancno", "hpcsano",
        "contactno", "profileimg", "address", "level", "added_by", "employmentStatus", "staffType",
         "adddate", "addtime", "status"  
      ) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15,
       $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29)
      RETURNING *;
    `;

    const insertResult = await con.query(insertQuery, [
      fname,
      lname,
      gender,
      username,
      email,
      hashedPassword,
      clinicId,
      roleid,
      desgid,
      deptId,
      dob,
      doj,
      maritalstatus,
      province,
      district,
      subdistrict,
      qualification,
      sancno,
      hpcsano,
      contactno,
      profileimg,
      address,
      level,
      added_by,
      employmentStatus,
      staffType,
      adddate,
      addtime,
      status
    ]);

    console.log('Database Insertion Result:', insertResult.rows[0]);

    // Send email in parallel (without blocking database insertion)
    const subject = 'Welcome to Our Clinic';
    const html = ` <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome Email</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f9f9f9;
      color: #333;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 600px;
      margin: 20px auto;
      background: #fff;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 5px;
    }
    h1 {
      color: #007bff;
      font-size: 22px;
      text-align: center;
    }
    p {
      font-size: 14px;
      line-height: 1.6;
    }
    ul {
      padding: 0;
      margin: 10px 0;
      list-style: none;
    }
    ul li {
      margin: 5px 0;
      padding: 8px;
      background: #f1f1f1;
      border-radius: 3px;
    }
    .cta {
      text-align: center;
      margin: 20px 0;
    }
    .cta a {
      text-decoration: none;
      color: #fff;
      background-color: #007bff;
      padding: 10px 20px;
      border-radius: 5px;
      font-size: 14px;
    }
    .cta a:hover {
      background-color: #0056b3;
    }
    .footer {
      text-align: center;
      font-size: 12px;
      color: #666;
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Welcome, ${fname}!</h1>
    <p>We’re thrilled to have you on board. Here are your registration details:</p>
    <ul>
      <li><b>Name:</b> ${fname} ${lname}</li>
      <li><b>Email:</b> ${email}</li>
      <li><b>Gender:</b> ${gender}</li>
      <li><b>Registration Date & Time:</b> ${adddate} ${addtime}</li>
    </ul>
    <p>If you have any questions, don’t hesitate to contact us. We’re here to help!</p>
    <div class="cta">
      <a href="http://139.84.235.68/login" target="_blank">Login to Your Account</a>
    </div>
    <div class="footer">
      <p>&copy; ${new Date().getFullYear()} Your Clinic. All rights reserved.</p>
    </div>
  </div>
</body>
</html>
        `;

    // Sending the email asynchronously
    const sendEmailPromise = sendEmail(email, subject, html);

    // Wait for both the insert result and email sending to complete
    await Promise.all([sendEmailPromise]);

    res.status(201).send({
      message: 'Clinic data inserted successfully, and email sent!',
      data: insertResult.rows[0]
    });
  } catch (err) {
    console.error('Error:', err);

    if (err.code === '23505') { // Unique constraint violation error code
      res.status(409).send({
        error: 'Conflict',
        message: 'A Staff with this email already exists.'
      });
    } else {
      res.status(500).send({
        error: 'Internal Server Error',
        details: err
      });
    }
  }
};

exports.checkEmailAvailabilitystaff = async (req, res) => {
  const { email } = req.body;

  // Query to check if the email already exists in the database
  const emailCheckQuery = `SELECT * FROM staff WHERE "email" = $1`;

  try {
    const emailCheckResult = await con.query(emailCheckQuery, [email]);
    if (emailCheckResult.rows.length > 0) {
      return res.status(409).send({
        error: 'Conflict',
        message: 'A staff with this email already exists.'
      });
    }
    return res.status(200).send({
      message: 'Email is available.'
    });
  } catch (err) {
    console.error('Error checking email:', err);
    res.status(500).send({
      error: 'Internal Server Error',
      details: err
    });
  }
};



exports.getstaff = (req, res) => {
  try {
    const get_query = `
                          SELECT s.*, c.*, des.*, dept.*, p.*, dis.*, r.*
                          FROM public.staff s
                          LEFT JOIN public.clinics c ON s."clinicId" = c."clinicid"
                          LEFT JOIN public.designation des ON s."desgid" = des."id"
                          LEFT JOIN public.department dept ON s."deptId" = dept."id"
                          LEFT JOIN public.province p ON s."province" = p."provinceId"
                          LEFT JOIN public.district dis ON s."district" = dis."districtId"
                          LEFT JOIN public.roles r ON s."roleid" = r."roleid"
                       `;
    con.query(get_query, (err, result) => {
      if (err) {
        console.error('Database Error:', err);
        return res.status(500).json({ error: 'Database query failed', details: err });
      }
      console.log('Query result:', result.rows);
      return res.json({ staff: result.rows });
    });
  } catch (err) {
    console.error('Unexpected error:', err);
    return res.status(500).json({ error: 'Internal Server Error', details: err });
  }
};


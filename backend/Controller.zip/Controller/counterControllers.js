const con = require('../db');

// Function to insert data
exports.insertCounter = (req, res) => {
 const { clinic_id, stream_id, current_token, current_tokenid, current_token_status, countername, countertype, counterdesc, counterstatus, added_by, date,time } = req.body;
 const insert_query = 'INSERT INTO counter(clinic_id, stream_id, current_token, current_tokenid, current_token_status, countername, countertype, counterdesc, counterstatus, added_by, date,time) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)';

 con.query(insert_query, [clinic_id, stream_id, current_token, current_tokenid, current_token_status, countername, countertype, counterdesc, counterstatus, added_by, date,time], (err, result) => {
  if (err) {
   res.status(500).send(err);
  } else {
   console.log(result);
   res.send("Counter Data Insert Successfully!");
  }
 });
};

// Function to get all data
exports.getCounter = (req, res) => {
 const get_query = 'SELECT * FROM public.counter';

 con.query(get_query, (err, result) => {
  if (err) {
   res.status(500).send(err);
  } else {
   console.log(result.rows);
   res.json(result.rows);
  }
 });
};

// Function to get data by ID
exports.getCounterById = (req, res) => {
 const { id } = req.params;
 const get_query = 'SELECT * FROM public.counter WHERE id = $1';

 con.query(get_query, [id], (err, result) => {
  if (err) {
   res.status(500).send(err);
  } else if (result.rows.length === 0) {
   res.status(404).send("Record not found");
  } else {
   console.log(result.rows);
   res.json(result.rows[0]);
  }
 });
};


// Function to update counter
exports.updateCounter = (req, res) => {
  const { id } = req.params;
  const { clinic_id, stream_id, current_token, current_tokenid, current_token_status, countername, countertype, counterdesc, counterstatus, added_by, date, time } = req.body;

  const update_query = `
    UPDATE public.counter 
    SET 
      clinic_id = $1, 
      stream_id = $2, 
      current_token = $3, 
      current_tokenid = $4, 
      current_token_status = $5, 
      countername = $6, 
      countertype = $7, 
      counterdesc = $8, 
      counterstatus = $9, 
      added_by = $10, 
      "date" = $11, 
      "time" = $12 
    WHERE id = $13`;

  con.query(update_query, [
    clinic_id, stream_id, current_token, current_tokenid, 
    current_token_status, countername, countertype, 
    counterdesc, counterstatus, added_by, date, time, id
  ], (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else if (result.rowCount === 0) {
      res.status(404).send("Record not found");
    } else {
      console.log(`Counter id ${id} updated`);
      res.send(`Counter id ${id} updated successfully`);
    }
  });
};


// Function to delete data by ID
exports.deleteCounter = (req, res) => {
 const { id } = req.params;
 const delete_query = 'DELETE FROM public.counter WHERE id = $1';

 con.query(delete_query, [id], (err, result) => {
  if (err) {
   res.status(500).send(err);
  } else if (result.rowCount === 0) {
   res.status(404).send("Record not found");
  } else {
   console.log(`Counter id ${id} deleted`);
   res.send(`Counter id ${id} deleted successfully`);
  }
 });
};




const con = require('../db');
const redisClient = require('../redis.js')

// Function to insert data
exports.insertDept = (req, res) => {
  const { clinic_id, deptname, deptdesc } = req.body;

  const now = new Date();
  const southAfricaTime = new Intl.DateTimeFormat('en-ZA', {
    timeZone: 'Africa/Johannesburg',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).formatToParts(now);

  const adddate = `${southAfricaTime[4].value.padStart(2, '0')}-${southAfricaTime[2].value.padStart(2, '0')}-${southAfricaTime[0].value}`;
  const addtime = `${southAfricaTime[6].value}:${southAfricaTime[8].value}:${southAfricaTime[10].value}`;
  const status = 'Active';
  const insert_query = `
    INSERT INTO public.department(clinic_id, deptname, deptdesc, status, adddate, addtime) 
    VALUES ($1, $2, $3, $4, $5, $6)
  `;

  con.query(insert_query, [clinic_id, deptname, deptdesc, status, adddate, addtime], (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else {
      console.log(result);
      res.send("Department Data Inserted Successfully!");
    }
  });
};

// Function to get clinic wise  all data
exports.getDept = (req, res) => {
  const { cid } = req.params;
  const get_query = 'SELECT * FROM public.department where clinic_id =$1';

  con.query(get_query, [cid], (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else {
      console.log(result.rows);
      res.json(result.rows);
    }
  });
};



// Function to get data by ID
exports.getDeptById = (req, res) => {
  const { id } = req.params;
  const get_query = 'SELECT * FROM public.department WHERE id = $1';

  con.query(get_query, [id], (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else if (result.rows.length === 0) {
      res.status(404).send("Record not found");
    } else {
      console.log(result.rows);
      res.json(result.rows[0]);
    }
  });
};

// Function to update data
exports.updateDept = (req, res) => {
  const { id } = req.params;
  const { clinic_id, deptname, deptdesc, status } = req.body;

  const update_query = `
    UPDATE public.department 
    SET 
      "clinic_id" = $1, 
      "deptname" = $2, 
      "deptdesc" = $3, 
      "status" = $4, 
    WHERE "id" = $5
  `;

  con.query(update_query, [clinic_id, deptname, deptdesc, status, id], (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else if (result.rowCount === 0) {
      res.status(404).send("Record not found");
    } else {
      console.log(`Department id ${id} data updated`);
      res.send(`Department id ${id} data updated successfully`);
    }
  });
};

// Function to delete data by ID
exports.deleteDept = (req, res) => {
  const { id } = req.params;
  const delete_query = 'DELETE FROM public.department WHERE id = $1';

  con.query(delete_query, [id], (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else if (result.rowCount === 0) {
      res.status(404).send("Record not found");
    } else {
      console.log(`Department id ${id} data deleted`);
      res.send(`Department id ${id} data deleted successfully`);
    }
  });
};

// Function to get all data
exports.getDepartment = (req, res) => {
  const get_query = 'SELECT * FROM public.department';

  con.query(get_query, (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else {
      console.log(result.rows);
      return res.json({ departments: result.rows });
    }
  });
};

